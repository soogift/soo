#!/bin/ash
hostnamefile="/mnt/logs/etc/hostname"
fw_printenv="/usr/local/bin/fw_printenv"

if ! [ -f $hostnamefile ]
then
	echo -n SP > $hostnamefile
	$fw_printenv ethaddr | sed -e 's|ethaddr=||' -e 's|:||g' -e 's|\(.*\)|\U\1|' >> $hostnamefile 
fi

/bin/hostname -F $hostnamefile
exit 0;
