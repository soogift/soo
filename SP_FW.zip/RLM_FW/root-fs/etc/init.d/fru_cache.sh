#!/bin/sh

# Cache Fru Info into a file
fruinfocachedfile_tmp="/tmp/fruinfocachedfile.txt"
fruinfocachedfile="/mnt/logs/ipmi/fruinfocachedfile.txt"

/usr/local/bin/oem_ipmi fru show-all > $fruinfocachedfile_tmp
mv $fruinfocachedfile_tmp  $fruinfocachedfile

